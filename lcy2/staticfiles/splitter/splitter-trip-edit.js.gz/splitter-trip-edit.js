$(document).ready(function(){
  $('form .input-daterange').datepicker({
      todayBtn: "linked",
      autoclose: true,
      format: "yyyy/mm/dd",
  });
});
